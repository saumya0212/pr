package com.noesis.voice.dto;

import java.util.ArrayList;
import java.util.List;

public class LoginFormData {
	private String userName;
	private String role;
	private String authToken;
	private int userId;
	private String logoUrl;
	private String emailId;
	
	private List<String> userAccounts;
	private String selectedUserAccount;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAuthToken() {
		return authToken;
	}
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
//	public char getIsVisualizeAllowed() {
//		return isVisualizeAllowed;
//	}
//	public void setIsVisualizeAllowed(char isVisualizeAllowed) {
//		this.isVisualizeAllowed = isVisualizeAllowed;
//	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
//	public String getLastLoginTime() {
//		return lastLoginTime;
//	}
//	public void setLastLoginTime(String lastLoginTime) {
//		this.lastLoginTime = lastLoginTime;
//	}
//	public String getLastLoginIp() {
//		return lastLoginIp;
//	}
//	public void setLastLoginIp(String lastLoginIp) {
//		this.lastLoginIp = lastLoginIp;
//	}
//	public ArrayList<String> getUserPrivileges() {
//		return userPrivileges;
//	}
//	public void setUserPrivileges(ArrayList<String> userPrivileges) {
//		this.userPrivileges = userPrivileges;
//	}
	public String getLogoUrl() {
		return logoUrl;
	}
	public void setLogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}
	public List<String> getUserAccounts() {
		return userAccounts;
	}
	public void setUserAccounts(List<String> userAccounts) {
		this.userAccounts = userAccounts;
	}
	public String getSelectedUserAccount() {
		return selectedUserAccount;
	}
	public void setSelectedUserAccount(String selectedUserAccount) {
		this.selectedUserAccount = selectedUserAccount;
	}
	
}
