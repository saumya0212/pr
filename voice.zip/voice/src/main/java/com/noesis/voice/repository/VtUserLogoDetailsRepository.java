package com.noesis.voice.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.noesis.voice.persistence.VtUserLogoDetails;



public interface VtUserLogoDetailsRepository extends CrudRepository<VtUserLogoDetails, Serializable> {
	public VtUserLogoDetails findByUserId(int userId);

}
