package com.noesis.voice.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import com.noesis.voice.persistence.VtUser;


public interface VtUserRepository  extends CrudRepository<VtUser, Serializable>{
	public VtUser findByUserName(String userName);

}
