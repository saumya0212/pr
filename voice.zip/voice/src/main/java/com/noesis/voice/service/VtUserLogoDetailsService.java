package com.noesis.voice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.noesis.voice.persistence.VtUserLogoDetails;
import com.noesis.voice.repository.VtUserLogoDetailsRepository;

@Service
public class VtUserLogoDetailsService {
	@Autowired
	VtUserLogoDetailsRepository vtUserLogoDetailsRepository;
	
	public VtUserLogoDetails findByUserId(int userId) {
		VtUserLogoDetails ngUserLogoDetails = vtUserLogoDetailsRepository.findByUserId(userId);
		return ngUserLogoDetails;
	}

	public VtUserLogoDetails saveUserLogoDetails(VtUserLogoDetails userLogoDetails) {
		VtUserLogoDetails savedUserLogoDetails = vtUserLogoDetailsRepository.save(userLogoDetails);
		return savedUserLogoDetails;
	}
}
