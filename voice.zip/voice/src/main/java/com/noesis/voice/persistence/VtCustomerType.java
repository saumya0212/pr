package com.noesis.voice.persistence;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "vt_customer_type", catalog = "voice")
public class VtCustomerType implements java.io.Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2965532704402447964L;
	private int id;
	private String custType;
	private String displayName;
	private String description;
	private Set<VtUser> vtUsers = new HashSet<VtUser>(0);

	public VtCustomerType() {
	}

	public VtCustomerType(int id) {
		this.id = id;
	}

	public VtCustomerType(int id, String custType, String displayName, String description, Set<VtUser> vtUsers) {
		this.id = id;
		this.custType = custType;
		this.displayName = displayName;
		this.description = description;
		this.vtUsers = vtUsers;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "cust_type", length = 45)
	public String getCustType() {
		return this.custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	@Column(name = "display_name", length = 45)
	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	@Column(name = "description", length = 45)
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "vtCustomerType")
	public Set<VtUser> getVtUsers() {
		return this.vtUsers;
	}

	public void setVtUsers(Set<VtUser> vtUsers) {
		this.vtUsers = vtUsers;
	}

}
