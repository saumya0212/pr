package com.noesis.voice.persistence;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name = "vt_plan", catalog = "voice")
public class VtPlan implements java.io.Serializable{
	
	
		/**
	 * 
	 */
	private static final long serialVersionUID = 3191538710210889204L;
		private int id;
		private String code;
		private String displayName;
		private String description;
		private Set<VtUser> vtUsers = new HashSet<VtUser>(0);

		public VtPlan() {
		}

		public VtPlan(int id) {
			this.id = id;
		}

		public VtPlan(int id, String code, String displayName, String description, Set<VtUser> vtUsers) {
			this.id = id;
			this.code = code;
			this.displayName = displayName;
			this.description = description;
			this.vtUsers = vtUsers;
		}

		@Id
		@GeneratedValue(strategy = IDENTITY)
		@Column(name = "id", unique = true, nullable = false)
		public int getId() {
			return this.id;
		}

		public void setId(int id) {
			this.id = id;
		}

		@Column(name = "cust_type", length = 45)
		public String getCode() {
			return this.code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		@Column(name = "display_name", length = 45)
		public String getDisplayName() {
			return this.displayName;
		}

		public void setDisplayName(String displayName) {
			this.displayName = displayName;
		}

		@Column(name = "description", length = 45)
		public String getDescription() {
			return this.description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		@OneToMany(fetch = FetchType.LAZY, mappedBy = "vtAccountType")
		public Set<VtUser> getVtUsers() {
			return this.vtUsers;
		}

		public void setVtUsers(Set<VtUser> vtUsers) {
			this.vtUsers = vtUsers;
		}

	}




