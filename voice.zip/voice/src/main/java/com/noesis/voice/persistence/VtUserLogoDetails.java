package com.noesis.voice.persistence;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vt_user_logo_details", catalog = "voice")
public class VtUserLogoDetails implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private int userId;
	private String logoPath;
	private String logoAccessUrl;

	
	
	public VtUserLogoDetails() {
	}

	public VtUserLogoDetails(int id, int userId, String logoPath,Set<VtUser> vtUsers) {
		super();
		this.id = id;
		this.userId = userId;
		this.logoPath = logoPath;
		
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "user_id", length = 11)
	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Column(name = "logo_path", length = 1000)
	public String getLogoPath() {
		return this.logoPath;
	}

	public void setLogoPath(String logoPath) {
		this.logoPath = logoPath;
	}

	@Column(name = "logo_access_url", length = 2000)
	public String getLogoAccessUrl() {
		return logoAccessUrl;
	}

	public void setLogoAccessUrl(String logoAccessUrl) {
		this.logoAccessUrl = logoAccessUrl;
	}
	
	
	
}
