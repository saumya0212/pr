package com.noesis.voice.dto;

public class LoginForm {
	private String userName;
	private String password;
//	private String appName;
//	private String userOtp;
	
//	public String getUserOtp() {
//		return userOtp;
//	}
//	public void setUserOtp(String userOtp) {
//		this.userOtp = userOtp;
//	}
//	public String getAppName() {
//		return appName;
//	}
//	public void setAppName(String appName) {
//		this.appName = appName;
//	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
