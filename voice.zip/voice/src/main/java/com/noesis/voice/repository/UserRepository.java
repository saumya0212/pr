package com.noesis.voice.repository;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.noesis.voice.persistence.User;
import com.noesis.voice.persistence.VtUser;


public interface UserRepository extends CrudRepository<User,Integer> {

 VtUser findByUserName(String username);

}
