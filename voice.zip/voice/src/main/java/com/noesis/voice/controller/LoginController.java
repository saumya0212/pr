package com.noesis.voice.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.noesis.voice.dto.LoginForm;
import com.noesis.voice.dto.LoginFormData;
import com.noesis.voice.dto.LoginFormResponse;
import com.noesis.voice.persistence.User;
import com.noesis.voice.persistence.VtUser;
import com.noesis.voice.repository.UserRepository;
import com.noesis.voice.repository.VtUserRepository;
//import com.noesis.voice.securityconfig.CustomUserDetailsService;
//import com.noesis.voice.securityconfig.JwtTokenUtil;
import com.noesis.voice.service.VtUserLogoDetailsService;
import com.noesis.voice.service.VtUserService;

	@RestController
	public class LoginController {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ObjectMapper objectMapper;
	
//	@Autowired
//	private AuthenticationManager authenticationManager;
	
//	@Autowired
//	private JwtTokenUtil jwtTokenUtil;
//	
	@Autowired
	private VtUserService vtUserService;
//	
//	@Autowired
//	private CustomUserDetailsService userDetailsService;
	
	@Autowired
	private VtUserLogoDetailsService userLogoDetailsService;
	
	@Autowired
	private VtUserRepository vtUserRepository;
	@Autowired
	private UserRepository userRepository;
	
	@RestController
	@RequestMapping("/voice")
	public class UserController {

	    @Autowired
	    private VtUserService vtUserService;
	    
	    @Autowired
	    private ObjectMapper objectMapper; // Assuming you have ObjectMapper configured

//	    @PostMapping("/user/login")
//	    public ResponseEntity<LoginFormResponse> loginUser(@RequestBody LoginForm loginForm, HttpServletRequest request) {
//	        try {
//	            String remoteAddress = request.getHeader("X-FORWARDED-FOR");
//	            logger.info("Login Request for user {}", loginForm.getUserName());
//
//	            VtUser vtUser = vtUserService.getUserByName(loginForm.getUserName());
//
//	            LoginFormResponse response = new LoginFormResponse();
//
//	            if (vtUser != null && loginForm.getPassword().equals(vtUser.getPassword())) {
//	                if ("client".equalsIgnoreCase(vtUser.getVtCustomerType().getCustType())) {
//	                    response.setCode(1001);
//	                    response.setMessage("Inactive user. Please contact support team.");
//	                    response.setResult("failure");
//	                } else {
//	                    response.setCode(1000);
//	                    response.setMessage("User login successful");
//	                    response.setResult("success");
//	                }
//	            } else {
//	                response.setCode(401); // Unauthorized
//	                response.setMessage("Authentication failed");
//	                response.setResult("failure");
//	            }
//
//	            return ResponseEntity.ok(response);
//	        } catch (Exception e) {
//	            // Log the exception and handle it appropriately
//	            logger.error("Error during login:", e);
//	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
//	        }
//	    }
//	}
//	
//	
	
	
	
	
//	---------------------------------------------------------------------------------------------------------------------
//	@RequestMapping(value = "/user/login", method = { RequestMethod.OPTIONS, RequestMethod.POST }, produces = {
//	"application/json" })
//	public String loginUser(@RequestBody LoginForm loginForm, HttpServletResponse resp,
//	@RequestHeader("X-FORWARDED-FOR") String remoteAddress) {
//
//		String jsonResponse = null;
//		logger.info("Login Request for user {}", loginForm.getUsername());
//		logger.info("Login Request for password {}", loginForm.getPassword());
//
//		VtUser vtUser = vtUserService.getUserByName(loginForm.getUsername());
//		LoginFormResponse response = new LoginFormResponse();
//		if (loginForm.getUsername().equals("admin") && loginForm.getPassword().equals("12345")) {
//			response = new LoginFormResponse();
//			LoginFormData data = generateAdminSuccessfulLoginResponse(loginForm, remoteAddress, vtUser);
//	// Set user privileges for user.
//			response.setCode(1000);
//			response.setData(data);
//			response.setMessage("User login successful");
////			response.setResult("success");
////			try {
////				response.setAuthJwtToken("Bearer " + createToken(loginForm));
////			} catch (Exception e) {
////		// TODO Auto-generated catch block
////				e.printStackTrace();
////			}
//		} else if (vtUser != null && loginForm.getUsername().equals(vtUser.getUserName())
//				&& loginForm.getPassword().equals(vtUser.getPassword())) {
//			response = new LoginFormResponse();
////			  if (vtUser.getVtStatus().getId() == 1) {
//				LoginFormData data = generateSuccessfulLoginResponse(loginForm, remoteAddress, vtUser);
//				response.setCode(1000);
//				response.setData(data);
//				response.setMessage("User login successful");
//				response.setResult("success");
//		}
//		
////				try {
////					response.setAuthJwtToken("Bearer " + createToken(loginForm));
////				} catch (Exception e) {
////			// TODO Auto-generated catch block
////					e.printStackTrace();
////				}
////			}
//			  else {
//				LoginFormData data = new LoginFormData();
//				data.setAuthToken(null);
//				data.setRole(null);
//				data.setUsername(loginForm.getUsername());
//				response.setCode(1001);
//				response.setData(null);
//				response.setMessage("Inactive user. Please contact support team.");
//				response.setResult("failure");
//				}
//		
//			 
//		try {
//			jsonResponse = objectMapper.writeValueAsString(response);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//		return jsonResponse;
//	}
//
//	private LoginFormData generateSuccessfulLoginResponse(LoginForm loginForm, String remoteAddress, VtUser vtUser) {
//		LoginFormData data = new LoginFormData();
//
//		ArrayList<String> userPrivilegesList = new ArrayList<>();
//		if (vtUser.getIsCreditHistoryAllowed() == 'Y') {
//			userPrivilegesList.add("SHOW_CREDIT_HISTORY");
//		}
////		if (ngUser.getNgDlrMediumType().getCode().equalsIgnoreCase("push")) {
////			userPrivilegesList.add("SHOW_CAMPAIGN_REPORT");
////		}
////		data.setUserPrivileges(userPrivilegesList);
//		VtUserLogoDetails userLogoDetails = userLogoDetailsService.findByUserId(vtUser.getParentId());
//		if (userLogoDetails != null) {
//			logger.info("logo Url {}", userLogoDetails.getLogoAccessUrl());
//			data.setLogoUrl(userLogoDetails.getLogoAccessUrl());
//		} else {
//			data.setLogoUrl(null);
//		}
////		NgUserLastLoginInfo userLastLoginInfo = userLastLoginInfoService.getUserLastLoginDetails(ngUser.getId(),
////				Constants.MIS_PANEL_APP_NAME);
////
////		if (userLastLoginInfo != null && userLastLoginInfo.getLastLoginTime() != null)
////			data.setLastLoginTime(
////					new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(userLastLoginInfo.getLastLoginTime()));
////
////		if (userLastLoginInfo != null && userLastLoginInfo.getLastLoginIp() != null)
////			data.setLastLoginIp(userLastLoginInfo.getLastLoginIp());
////
////		// Update new last login details:
////		if (userLastLoginInfo == null) {
////			userLastLoginInfo = new NgUserLastLoginInfo();
////			userLastLoginInfo.setUserId(ngUser.getId());
////			userLastLoginInfo.setAppName(Constants.MIS_PANEL_APP_NAME);
////		}
////		userLastLoginInfo.setLastLoginTime(new Date());
////		if (remoteAddress == null || "".equals(remoteAddress)) {
////			userLastLoginInfo.setLastLoginIp("");
////		} else {
////			userLastLoginInfo.setLastLoginIp(remoteAddress);
////		}
////		userLastLoginInfoService.updateUserLoginDetails(userLastLoginInfo);
//
//		data.setAuthToken("1a2b3c4d5e6f7g8h9i");
//		data.setRole("client");
//		data.setUsername(loginForm.getUsername());
//		return data;
//	}
//	
//	
////	private void authenticate(String username, String password) throws Exception {
////		try {
////			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
////		} catch (DisabledException e) {
////			throw new Exception("USER_DISABLED", e);
////		} catch (BadCredentialsException e) {
////			throw new Exception("INVALID_CREDENTIALS", e);
////		}
////	}
//
////	private String createToken(LoginForm loginForm) throws Exception {
////		try {
////			authenticate(loginForm.getUsername(), loginForm.getPassword());
////		} catch (Exception e1) {
////			// TODO Auto-generated catch block
////			e1.printStackTrace();
////		}
////		final UserDetails userDetails = userDetailsService.loadUserByUsername(loginForm.getUsername());
////		final String token = jwtTokenUtil.generateToken(userDetails);
////		return token;
////
////	}
//
//	private LoginFormData generateAdminSuccessfulLoginResponse(LoginForm loginForm, String remoteAddress,
//			VtUser vtUser) {
//		try {
//
//			LoginFormData data = new LoginFormData();
//			data.setAuthToken("1a2b3c4d5e6f7g8h9i");
//			data.setRole("admin");
//
//			data.setUsername(loginForm.getUsername());
//			VtUserLogoDetails userLogoDetails = userLogoDetailsService.findByUserId(vtUser.getParentId());
//			if (userLogoDetails != null) {
//				logger.info("logo Url {}", userLogoDetails.getLogoAccessUrl());
//				data.setLogoUrl(userLogoDetails.getLogoAccessUrl());
//			} else {
//				data.setLogoUrl(null);
//			}
//			ArrayList<String> userPrivilegesList = new ArrayList<>();
//			if (vtUser.getIsCreditHistoryAllowed() == 'Y') {
//				userPrivilegesList.add("SHOW_CREDIT_HISTORY");
//			}
////			if (ngUser.getNgDlrMediumType().getCode().equalsIgnoreCase("push")) {
////				userPrivilegesList.add("SHOW_CAMPAIGN_REPORT");
////			}
////			data.setUserPrivileges(userPrivilegesList);
//
////			NgUserLastLoginInfo userLastLoginInfo = userLastLoginInfoService.getUserLastLoginDetails(ngUser.getId(),
////					Constants.MIS_PANEL_APP_NAME);
////
////			if (userLastLoginInfo != null && userLastLoginInfo.getLastLoginTime() != null)
////				data.setLastLoginTime(
////						new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(userLastLoginInfo.getLastLoginTime()));
////
////			if (userLastLoginInfo != null && userLastLoginInfo.getLastLoginIp() != null)
////				data.setLastLoginIp(userLastLoginInfo.getLastLoginIp());
////
////			// Update new last login details:
////			if (userLastLoginInfo == null) {
////				userLastLoginInfo = new NgUserLastLoginInfo();
////				userLastLoginInfo.setUserId(ngUser.getId());
////				userLastLoginInfo.setAppName(Constants.MIS_PANEL_APP_NAME);
////			}
////			userLastLoginInfo.setLastLoginTime(new Date());
////			if (remoteAddress == null || "".equals(remoteAddress)) {
////				userLastLoginInfo.setLastLoginIp("");
////			} else {
////				userLastLoginInfo.setLastLoginIp(remoteAddress);
////			}
////			userLastLoginInfoService.updateUserLoginDetails(userLastLoginInfo);
//			return data;
//		} catch (Exception e) {
//			return null;
//		}
//	}
//	@RequestMapping(value = "/user/login", method = { RequestMethod.OPTIONS, RequestMethod.POST }, produces = {
//	"application/json" })
//	    @PostMapping("/user/login")
//public ResponseEntity<LoginFormResponse> loginUser( @PathVariable @RequestBody  LoginForm loginForm, HttpServletResponse resp,
//	@RequestHeader("X-FORWARDED-FOR") String remoteAddress) {
//
//String jsonResponse = null;
//logger.info("Login Request for user {}", loginForm.getUserName());
//logger.info("Login Request for password {}", loginForm.getPassword());
//
//
//
//VtUser vtUser = vtUserService.getUserByName(loginForm.getUserName());
// 
//	
//LoginFormResponse response = new LoginFormResponse();
//if (vtUser != null && loginForm.getUserName().equals(vtUser.getUserName())
//		&& loginForm.getPassword().equals(vtUser.getPassword())) {
//	if (vtUser.getVtCustomerType().getCustType().equalsIgnoreCase("client")) {
//		LoginFormData data = new LoginFormData();
//		data.setAuthToken(null);
//		data.setRole(null);
//		data.setUserName(loginForm.getUserName());
//		data.setLogoUrl(null);
//		response.setCode(1001);
//		response.setData(null);
//		response.setMessage("Inactive user. Please contact support team.");
//		response.setResult("failure");
//	} else {
//				response.setCode(1000);
//				response.setData(null);
//				response.setMessage("User login successful");
//				response.setResult("success");
//			}
//		}
//try {
//
//	jsonResponse = objectMapper.writeValueAsString(response);
//} catch (JsonProcessingException e) {
//	e.printStackTrace();
//} catch (Exception e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//}
//return new ResponseEntity<LoginFormResponse>(response,HttpStatus.OK);
//	}}
	
//	@GetMapping("/getAllData")
//	public Iterable<VtUser> getAllProducts(){
//	return vtUserRepository.findAll();
//	}
	
	@PostMapping("/createProduct")
	public User createUser (@RequestBody User user) {
	return userRepository.save(user);
	}
	
	
	
	
	
	}}
	
