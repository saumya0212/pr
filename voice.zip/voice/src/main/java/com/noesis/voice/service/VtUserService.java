package com.noesis.voice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.noesis.voice.persistence.VtUser;
import com.noesis.voice.repository.VtUserRepository;
@Service
public class VtUserService {
	 private final Logger logger = LoggerFactory.getLogger(getClass());
	 
	 @Autowired
	private VtUserRepository vtUserRepository;
	
	
	public VtUser getUserByName(String userName) {
		logger.info("Thread id :" + Thread.currentThread().getId()
				+" : Getting user by user name from service {}.", userName);
		VtUser user = vtUserRepository.findByUserName(userName);
		if(user !=null) {
			logger.info("Thread id :" + Thread.currentThread().getId()
					+" : User password is from service: " + user.getPassword());
		}
		return user;
	}

}
