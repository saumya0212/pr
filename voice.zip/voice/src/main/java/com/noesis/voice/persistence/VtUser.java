package com.noesis.voice.persistence;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name = "vt_user", catalog = "voice")
public class VtUser implements java.io.Serializable  {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3366245990333164218L;
	private Integer id;
	private String userName;
	private String password;
	private String confirmPassword;
	private String name;
	private String email;
	private String phoneNumber;
	private String companyName;
	private Integer pincode;
	private VtCustomerType vtCustomerType;
	private VtAccountType vtAccountType;
	private VtPlan vtplan;
	private String address;
	private Integer channel;
	private Date expiry;
//	private VtUserLogoDetails vtUserLogoDetails;
	private String domain;
	private char isCreditHistoryAllowed;
	private int parentId;
	//private VtStatus vtStatus;
	
	private VtUser() {
		
	}

	public VtUser(Integer id, String userName, String password, String confirmPassword, String name, String email,
			String phoneNumber, String companyName, Integer pincode, VtCustomerType vtCustomerType,
			VtAccountType vtAccountType, VtPlan vtplan, String address, Integer channel, Date expiry,
			VtUserLogoDetails vtUserLogoDetails, String domain,char isCreditHistoryAllowed,  int parentId
			) {
		super();
		this.id = id;
		this.userName = userName;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.name = name;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.companyName = companyName;
		this.pincode = pincode;
		this.vtCustomerType = vtCustomerType;
		this.vtAccountType = vtAccountType;
		this.vtplan = vtplan;
		this.address = address;
		this.channel = channel;
		this.expiry = expiry;
	//	this.vtUserLogoDetails = vtUserLogoDetails;
		this.domain = domain;
		this.isCreditHistoryAllowed=isCreditHistoryAllowed;
		this.parentId=parentId;
//		this.vtStatus = vtStatus;
	}
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name = "user_name", nullable = false, length = 45)
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Column(name = "password", nullable = false, length = 45)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	@Column(name = "confirm_password", nullable = false, length = 45)
	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@Column(name = "name", nullable = false, length = 45)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Column(name = "email", nullable = false, length = 45)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name = "phone_number", nullable = false, length = 45)
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Column(name="company",nullable= false, length=45)
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	@Column(name="pincode",nullable= false, length=10)
	public Integer getPincode() {
		return pincode;
	}

	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_type", nullable = false)
	@JsonBackReference
	public VtCustomerType getVtCustomerType() {
		return vtCustomerType;
	}
	
	public void setVtCustomerType(VtCustomerType vtCustomerType) {
		this.vtCustomerType = vtCustomerType;
	}
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "account_type")
	@JsonBackReference
	public VtAccountType getVtAccountType() {
		return vtAccountType;
	}

	public void setVtAccountType(VtAccountType vtAccountType) {
		this.vtAccountType = vtAccountType;
	}
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "plan", nullable = false)
	@JsonBackReference
	public VtPlan getVtplan() {
		return vtplan;
	}

	public void setVtplan(VtPlan vtplan) {
		this.vtplan = vtplan;
	}
	@Column(name="address",nullable= false, length=45)
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name="channel",nullable= false, length=45)
	public Integer getChannel() {
		return channel;
	}

	public void setChannel(Integer channel) {
		this.channel = channel;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expiry", length = 19)
	public Date getExpiry() {
		return expiry;
	}

	public void setExpiry(Date expiry) {
		this.expiry = expiry;
	}
//	@ManyToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "logo_details")
//	@JsonBackReference
//	public VtUserLogoDetails getVtUserLogoDetails() {
//		return vtUserLogoDetails;
//	}
//
//	public void setVtUserLogoDetails(VtUserLogoDetails vtUserLogoDetails) {
//		this.vtUserLogoDetails = vtUserLogoDetails;
//	}
	@Column(name="domain",nullable= false, length=45)
	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}
	@Column(name = "is_credit_history_allowed", nullable = false, length = 1)
	public char getIsCreditHistoryAllowed() {
		return isCreditHistoryAllowed;
	}
//	@Column(name="status",nullable= false, length=15)
//	public VtStatus getVtStatus() {
//		return vtStatus;
//	}
//
//	public void setVtStatus(VtStatus vtStatus) {
//		this.vtStatus = vtStatus;
//	}

	public void setIsCreditHistoryAllowed(char isCreditHistoryAllowed) {
		this.isCreditHistoryAllowed = isCreditHistoryAllowed;
	}
	@Column(name="parent_id",nullable= false, length=10)
	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}
	
	
	
	

}

