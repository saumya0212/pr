package com.noesis.voice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
